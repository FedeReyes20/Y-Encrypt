#include<iostream>
#include<string>
using namespace std;
  
void mes() {
  
      cout << "what is the message?\n" <<"Must be single string no symbols or spaces."<<endl;
      
}
void mesd() {0
  
      cout << "what is the encrypted message?\n" <<"Must be single string no symbols or spaces."<<endl;
      
}
string vigenereCipher(string text,string key,bool operation)
{
  for (int i = 0; i < text.length(); i++) {
		text[i] = toupper(text[i]);
	}

   string outString;
   if(operation)
   {
       for (int i = 0, j = 0; i < text.length(); ++i)
       {
           char c = text[i];
           if (c >= 'A' && c <= 'Z')
           {
               outString += (c + key[j] - 2 * 'A') % 26 + 'A';
j = (j + 1) % key.length();
           }
           else
               outString+=c;
       }
   }
   else
   {
       for (int i = 0, j = 0; i < text.length(); ++i)
{
char c = text[i];
               if (c >= 'A' && c <= 'Z')
               {
                   outString += (c - key[j] + 26) % 26 + 'A';
                   j = (j + 1) % key.length();
               }
               else
                   outString+=c;
}
   }
   return outString;
}

  
// Driver program to test the above function
int main()
{
  int choice;
  string word[4] = {"IMPORT", "BUILD","MONEY", "DOC"};
  cout << "This program encrypts or decrypts messages. \n Press 1 to encrypt\n Press 2 to decrypt\n"<<endl;
  cin >> choice;

  if (choice == 1)
	{
    int option;
		cout << "Encryption was chosen. \n" << endl;
    cout << " Who are you sending the message?\n 1. President\n 2. Operations manager.\n 3. Accountant.\n 4.Office manager.\n " <<endl;

    cin >> option;


    if ( option == 1){
      string message;
      mes();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[0] ,true);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";
	}
  else if(option == 2) {

   string message;
      mes();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[1] ,true);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
  else if(option == 3) {

   string message;
      mes();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[2] ,true);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
   else if(option == 4) {

   string message;
      mes();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[3] ,true);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
  else{
    cout << " Wrong option\n Restart the program";
  }
    }

		
else if (choice == 2)
	{
		int option;
		cout << "Decryption was chosen. \n" << endl;
    cout << " from whom did you receive the message? \n 1. President\n 2. Operations manager.\n 3. Accountant.\n 4.Office manager.\n " << endl;

    cin >> option;


    if ( option == 1){
      string message;
      mesd();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[0] ,false);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";
	}
  else if(option == 2) {

   string message;
      mesd();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[1] ,false);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
  else if(option == 3) {

   string message;
      mesd();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[2] ,false);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
   else if(option == 4) {

   string message;
      mesd();
      cin >> message;
      string cipher_text1 = vigenereCipher(message, word[3] ,false);
      cout<<"Original message is: "<< message << endl;
      cout << "Ciphertext : "<< cipher_text1 << "\n\n";

  }
  else{
    cout << " Wrong option\n Restart the program";
  }
	}
  else{
    cout << " Wrong option\n Restart the program";
  }



return 0;
  
}